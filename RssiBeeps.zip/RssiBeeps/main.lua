local delayMs = 10
local nextPlay = getTime()

local options = {
  { "Option1", SOURCE, 1 },
  { "Option2", VALUE, 1000 },
  { "Option3", COLOR, RED }
}

local function create(zone, options)
	local data = { zone=zone, options=options, rssiNum=0}
	return data
end


local function update(data, options)
	data.options = options
end

local function background(data)
	data.rssiNum =  getValue("RSSI")
end


function refresh(data)
	lcd.drawText(data.zone.x, data.zone.y, "rssi", LEFT + DBLSIZE + TEXT_COLOR);
	lcd.drawNumber(data.zone.x, data.zone.y+50, getValue("RSSI"), LEFT + DBLSIZE + TEXT_COLOR);

	if getTime() >= nextPlay then
		playFile("/SOUNDS/en/sbeep.wav")
		--nextPlay = getTime() + delayMs - getValue("RSSI")
		nextPlay = getTime() + delayMs + getValue("RSSI")
	end
end


return { name="RssiBeeps", options=options, create=create, update=update, refresh=refresh, background=background }